import { motion } from 'motion/react';
import { processData } from '../data';
import { SectionHeading } from './SectionHeading';

export function Process() {
  return (
    <section id="process" className="py-24 bg-slate-50 dark:bg-[#0a0f1c] relative">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading 
          title="How We Work" 
          subtitle="Our Process" 
        />
        
        <div className="max-w-4xl mx-auto mt-16 relative">
          {/* Vertical line connecting steps (hidden on small screens) */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-brand-200 dark:via-brand-900/50 to-transparent -translate-x-1/2" />
          
          <div className="space-y-12 md:space-y-0 relative">
            {processData.map((step, index) => {
              const isEven = index % 2 === 0;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className={`flex flex-col md:flex-row items-center gap-8 ${
                    isEven ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  <div className={`w-full md:w-1/2 ${isEven ? 'md:text-left' : 'md:text-right'}`}>
                    <div className="p-8 rounded-3xl glass-card relative group">
                      <span className="absolute top-6 right-6 text-6xl font-display font-bold text-slate-100 dark:text-slate-800/50 pointer-events-none group-hover:scale-110 transition-transform">
                        {step.step}
                      </span>
                      <h3 className="text-xl font-display font-semibold text-slate-900 dark:text-white mb-4 relative z-10">
                        {step.title}
                      </h3>
                      <p className="text-slate-600 dark:text-slate-400 leading-relaxed relative z-10">
                        {step.description}
                      </p>
                    </div>
                  </div>
                  
                  {/* Center Dot */}
                  <div className="hidden md:flex w-12 h-12 rounded-full bg-white dark:bg-slate-900 border-4 border-brand-100 dark:border-brand-900/50 items-center justify-center z-10 shadow-sm relative">
                    <div className="w-3 h-3 rounded-full bg-brand-600 dark:bg-brand-500" />
                  </div>
                  
                  <div className="hidden md:block w-full md:w-1/2" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
