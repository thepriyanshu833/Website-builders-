import { motion } from 'motion/react';
import { maintenanceData } from '../data';
import { SectionHeading } from './SectionHeading';
import { ShieldCheck } from 'lucide-react';

export function Maintenance() {
  return (
    <section className="py-24 bg-slate-900 dark:bg-slate-900 relative overflow-hidden">
      {/* Dark section for contrast */}
      <div className="absolute inset-0 pointer-events-none -z-10">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-900/10 blur-[100px]" />
      </div>

      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.span 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block py-1 px-3 rounded-full bg-white/10 text-brand-300 text-sm font-semibold tracking-wider uppercase mb-4"
          >
            Complete Peace of Mind
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight"
          >
            Ongoing Website Maintenance
          </motion.h2>
          <motion.p
             initial={{ opacity: 0, y: 10 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ delay: 0.2 }}
             className="text-slate-400 text-lg mt-6 max-w-2xl mx-auto"
          >
            We don't just launch your site and disappear. Our comprehensive maintenance ensures your digital storefront is always fast, secure, and up-to-date.
          </motion.p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-4 mt-12">
          {maintenanceData.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="flex flex-col items-center text-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
              >
                <Icon className="w-6 h-6 text-brand-400 mb-4" />
                <span className="text-slate-200 text-sm font-medium leading-tight">
                  {item.title}
                </span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
