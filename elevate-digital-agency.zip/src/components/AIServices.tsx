import { motion } from 'motion/react';
import { aiServicesData } from '../data';
import { SectionHeading } from './SectionHeading';

export function AIServices() {
  return (
    <section id="ai-services" className="py-24 bg-white dark:bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          
          <div className="lg:w-1/3 lg:sticky lg:top-32">
            <SectionHeading 
              title="Work Smarter, Not Harder" 
              subtitle="AI Automation"
              align="left"
            />
            <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed mb-8">
              Transform your website from a simple brochure into an active employee. Our premium AI integrations work 24/7 to capture leads, answer questions, and schedule appointments while you focus on your core business.
            </p>
          </div>
          
          <div className="lg:w-2/3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {aiServicesData.map((service, index) => {
                const Icon = service.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: (index % 4) * 0.1 }}
                    className="p-6 rounded-2xl border border-slate-100 dark:border-slate-800/60 bg-slate-50/50 dark:bg-slate-900/30 hover:bg-white dark:hover:bg-slate-900 transition-colors group"
                  >
                    <div className="flex items-center gap-4 mb-3">
                      <div className="p-2.5 rounded-xl bg-white dark:bg-slate-800 shadow-sm text-brand-600 dark:text-brand-400 group-hover:scale-110 transition-transform">
                        <Icon className="w-5 h-5" />
                      </div>
                      <h4 className="font-display font-semibold text-slate-900 dark:text-white text-lg">
                        {service.title}
                      </h4>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 text-sm">
                      {service.benefit}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
