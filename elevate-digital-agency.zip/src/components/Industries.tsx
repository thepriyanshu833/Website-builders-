import { motion } from 'motion/react';
import { industriesData } from '../data';
import { SectionHeading } from './SectionHeading';

export function Industries() {
  return (
    <section className="py-24 bg-slate-50 dark:bg-[#0a0f1c] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading 
          title="Who We Serve" 
          subtitle="Specialized Solutions" 
        />
        
        <div className="mt-16 flex flex-wrap justify-center gap-3 md:gap-4 max-w-5xl mx-auto">
          {industriesData.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.02 }}
              className="px-5 py-3 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-medium text-sm md:text-base shadow-sm hover:shadow-md hover:border-brand-300 dark:hover:border-brand-700 hover:text-brand-600 dark:hover:text-brand-400 transition-all cursor-default"
            >
              {industry}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
