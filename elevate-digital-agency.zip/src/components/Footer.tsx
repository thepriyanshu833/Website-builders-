import { ArrowRight, Instagram, Linkedin, Twitter } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-slate-300 py-16 lg:py-24 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
          
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center">
                <span className="text-white font-display font-bold text-xl leading-none">E</span>
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-white">
                Elevate Digital
              </span>
            </div>
            <p className="text-slate-400 mb-8 max-w-sm leading-relaxed">
              We help local businesses scale with premium, handcrafted websites and intelligent AI automations. Focus on your business while we handle your digital growth.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-brand-600 hover:text-white transition-colors" aria-label="Twitter">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-brand-600 hover:text-white transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-brand-600 hover:text-white transition-colors" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#features" className="hover:text-brand-400 transition-colors">Services</a></li>
              <li><a href="#portfolio" className="hover:text-brand-400 transition-colors">Our Work</a></li>
              <li><a href="#process" className="hover:text-brand-400 transition-colors">Process</a></li>
              <li><a href="#contact" className="hover:text-brand-400 transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-6">Solutions</h4>
            <ul className="space-y-4">
              <li><a href="#features" className="hover:text-brand-400 transition-colors">Premium Web Design</a></li>
              <li><a href="#ai-services" className="hover:text-brand-400 transition-colors">AI Integrations</a></li>
              <li><a href="#ai-services" className="hover:text-brand-400 transition-colors">Smart Automations</a></li>
              <li><a href="#maintenance" className="hover:text-brand-400 transition-colors">Ongoing Maintenance</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-6">Stay Updated</h4>
            <p className="text-slate-400 text-sm mb-4">Get the latest digital growth strategies for local businesses.</p>
            <form className="relative" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Email address" 
                className="w-full bg-slate-900 border border-slate-800 rounded-lg py-3 pl-4 pr-12 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all text-white placeholder-slate-500"
              />
              <button 
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-brand-600 hover:bg-brand-500 rounded-md flex items-center justify-center text-white transition-colors"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

        </div>

        <div className="mt-16 pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm">
            © {currentYear} Elevate Digital Agency. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
