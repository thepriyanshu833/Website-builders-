import { motion } from 'motion/react';
import { SectionHeading } from './SectionHeading';
import { Mail, MessageCircle, MapPin, Send } from 'lucide-react';

export function Contact() {
  return (
    <section id="contact" className="py-24 bg-white dark:bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading 
          title="Let's Build Something Great" 
          subtitle="Get in Touch" 
        />
        
        <div className="flex flex-col lg:flex-row gap-12 mt-16">
          {/* Contact Info & Map */}
          <div className="lg:w-1/2 space-y-8">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="glass-card p-8 rounded-3xl"
            >
              <h3 className="text-2xl font-display font-semibold text-slate-900 dark:text-white mb-6">
                Start Your Project Today
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-brand-50 dark:bg-slate-800 flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5 text-brand-600 dark:text-brand-400" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white mb-1">WhatsApp Us</p>
                    <a href="#" className="text-slate-600 dark:text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                      Available 24/7 for quick queries
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-brand-50 dark:bg-slate-800 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5 text-brand-600 dark:text-brand-400" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white mb-1">Email Us</p>
                    <a href="mailto:hello@elevatedigital.agency" className="text-slate-600 dark:text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                      hello@elevatedigital.agency
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-brand-50 dark:bg-slate-800 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-brand-600 dark:text-brand-400" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white mb-1">Global Agency</p>
                    <p className="text-slate-600 dark:text-slate-400">
                      Serving premium clients worldwide with dedicated support.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Map Placeholder */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="h-64 rounded-3xl overflow-hidden bg-slate-100 dark:bg-slate-900 relative"
            >
              <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 p-6 text-center">
                <MapPin className="w-8 h-8 mb-2 opacity-50" />
                <p className="font-medium">Google Maps Integration</p>
                <p className="text-sm">Location mapping placeholder</p>
              </div>
            </motion.div>
          </div>

          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2"
          >
            <div className="glass-panel p-8 md:p-10 rounded-3xl">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      Full Name
                    </label>
                    <input 
                      type="text" 
                      id="name" 
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:bg-slate-900/50 dark:border-slate-700 dark:focus:border-brand-500 outline-none transition-all dark:text-white"
                      placeholder="John Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      Email Address
                    </label>
                    <input 
                      type="email" 
                      id="email" 
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:bg-slate-900/50 dark:border-slate-700 dark:focus:border-brand-500 outline-none transition-all dark:text-white"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="business" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Business Name & Type
                  </label>
                  <input 
                    type="text" 
                    id="business" 
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:bg-slate-900/50 dark:border-slate-700 dark:focus:border-brand-500 outline-none transition-all dark:text-white"
                    placeholder="e.g. Apex Dental Clinic"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Project Details
                  </label>
                  <textarea 
                    id="message" 
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 dark:bg-slate-900/50 dark:border-slate-700 dark:focus:border-brand-500 outline-none transition-all resize-none dark:text-white"
                    placeholder="Tell us about your goals..."
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-medium text-lg transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 group"
                >
                  Send Message
                  <Send className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
