import { motion } from 'motion/react';
import { testimonialsData } from '../data';
import { SectionHeading } from './SectionHeading';
import { Star } from 'lucide-react';

export function Testimonials() {
  return (
    <section className="py-24 bg-white dark:bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-6">
        <SectionHeading 
          title="Client Success Stories" 
          subtitle="Testimonials" 
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          {testimonialsData.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-3xl glass-card flex flex-col justify-between"
            >
              <div>
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-slate-700 dark:text-slate-300 italic mb-8 leading-relaxed">
                  "{testimonial.review}"
                </p>
              </div>
              <div className="flex items-center gap-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  loading="lazy"
                  className="w-12 h-12 rounded-full object-cover border-2 border-brand-100 dark:border-brand-900/30"
                />
                <div>
                  <h4 className="font-semibold text-slate-900 dark:text-white text-sm">
                    {testimonial.name}
                  </h4>
                  <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">
                    {testimonial.profession}, {testimonial.business}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
