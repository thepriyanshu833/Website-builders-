import {
  MonitorSmartphone, ShieldCheck, Zap, BarChart, Settings, Layout, Globe, Search,
  MessageSquare, Phone, CalendarCheck, Users, Headphones, Star, HelpCircle, Mail,
  FormInput, LineChart, Target, Megaphone, Repeat, Briefcase,
  RefreshCw, Lock, Database, Gauge, Bug, FileEdit, Activity, HeartPulse, LifeBuoy,
  Rocket, Key, AlertTriangle, CheckCircle
} from 'lucide-react';

export const featuresData = [
  {
    title: 'Modern Designs',
    description: 'Beautiful, handcrafted interfaces that capture your brand essence and engage visitors.',
    icon: Layout,
  },
  {
    title: 'Mobile Friendly',
    description: 'Flawless responsive experiences across all devices, from smartphones to large desktop displays.',
    icon: MonitorSmartphone,
  },
  {
    title: 'SEO Optimized',
    description: 'Built with technical SEO best practices to help your business rank higher on Google.',
    icon: Search,
  },
  {
    title: 'Fast Loading',
    description: 'Optimized assets and clean code ensure lightning-fast page speeds for better conversions.',
    icon: Zap,
  },
  {
    title: 'Secure',
    description: 'Enterprise-grade security protocols to protect your data and build customer trust.',
    icon: ShieldCheck,
  },
  {
    title: 'Easy to Manage',
    description: 'Intuitive systems that make updating your content as simple as sending an email.',
    icon: Settings,
  },
  {
    title: 'Business Growth Focused',
    description: 'Strategic layouts designed specifically to turn your casual visitors into paying customers.',
    icon: BarChart,
  },
  {
    title: 'Conversion Optimized',
    description: 'Data-driven UI/UX decisions that reduce friction and maximize your conversion rates.',
    icon: Target,
  },
];

export const industriesData = [
  "Beauty Salon", "Barber Shop", "Spa", "Gym & Fitness", "Yoga Studio", 
  "Dental Clinic", "Hospital", "Medical Laboratory", "Pharmacy", 
  "Restaurant", "Cafe", "Bakery", "Hotel", "Resort", 
  "Coaching Institute", "School", "College", "Tuition Centre", 
  "Real Estate", "Construction Company", "Interior Designer", 
  "Furniture Store", "Electronics Shop", "Mobile Shop", "Garment Shop", 
  "Jewellery Shop", "Grocery Store", "Sweet Shop", "Car Showroom", 
  "Bike Showroom", "Car Service Center", "Travel Agency", "Event Planner", 
  "Photographer", "Wedding Planner", "Lawyer", "Chartered Accountant", 
  "Insurance Advisor", "Financial Consultant", "NGO", "Printing Press", 
  "Home Services", "Repair Services", "Any Other Local Business"
];

export const aiServicesData = [
  { title: 'AI Chatbot', benefit: 'Engage website visitors 24/7 and answer common questions instantly.', icon: MessageSquare },
  { title: 'WhatsApp Automation', benefit: 'Automatically reply to inquiries and send targeted broadcasts.', icon: Phone },
  { title: 'AI Appointment Booking', benefit: 'Let AI handle scheduling, reminders, and calendar management.', icon: CalendarCheck },
  { title: 'AI Lead Collection', benefit: 'Capture visitor details conversationally without boring forms.', icon: Users },
  { title: 'AI Customer Support', benefit: 'Resolve tier-1 support tickets automatically round the clock.', icon: Headphones },
  { title: 'AI Review Collection', benefit: 'Automatically request and manage reviews from happy customers.', icon: Star },
  { title: 'AI FAQ Assistant', benefit: 'Instantly surface the right information based on user intent.', icon: HelpCircle },
  { title: 'AI Email Automation', benefit: 'Send personalized follow-ups that sound human and drive sales.', icon: Mail },
  { title: 'AI Smart Contact Forms', benefit: 'Dynamically adapt form fields based on what the user types.', icon: FormInput },
  { title: 'AI Analytics Dashboard', benefit: 'Get plain-English insights from your complex business data.', icon: LineChart },
  { title: 'AI Lead Qualification', benefit: 'Score and filter prospects automatically before you even speak to them.', icon: Target },
  { title: 'AI Marketing Automation', benefit: 'Trigger hyper-personalized campaigns based on user behavior.', icon: Megaphone },
  { title: 'AI Follow-up System', benefit: 'Never lose a lead again with persistent, intelligent nurturing.', icon: Repeat },
  { title: 'AI Business Assistant', benefit: 'Your personal AI executive to summarize reports and tasks.', icon: Briefcase },
];

export const maintenanceData = [
  { title: 'Website Updates', icon: RefreshCw },
  { title: 'Security Monitoring', icon: Lock },
  { title: 'Regular Backup', icon: Database },
  { title: 'Performance Optimization', icon: Gauge },
  { title: 'Bug Fixes', icon: Bug },
  { title: 'Content Updates', icon: FileEdit },
  { title: 'SEO Maintenance', icon: Search },
  { title: 'Uptime Monitoring', icon: Activity },
  { title: 'Monthly Health Check', icon: HeartPulse },
  { title: 'Technical Support', icon: LifeBuoy },
  { title: 'Speed Optimization', icon: Rocket },
  { title: 'New Feature Updates', icon: Zap },
  { title: 'Security Patches', icon: ShieldCheck },
  { title: 'Emergency Fixes', icon: AlertTriangle },
];

export const processData = [
  { step: '01', title: 'Consultation', description: 'We discuss your goals, target audience, and specific business needs to establish a solid foundation.' },
  { step: '02', title: 'Planning', description: 'Creating a strategic roadmap, sitemap, and architecture for your digital presence.' },
  { step: '03', title: 'Design', description: 'Crafting premium, tailored visual layouts that align perfectly with your brand identity.' },
  { step: '04', title: 'Development', description: 'Translating designs into clean, fast-loading, and responsive code.' },
  { step: '05', title: 'Testing', description: 'Rigorous quality assurance across all devices and browsers to ensure flawless execution.' },
  { step: '06', title: 'Launch', description: 'Deploying your new platform seamlessly to the live server with zero downtime.' },
  { step: '07', title: 'Ongoing Support', description: 'Continuous monitoring, updates, and optimization to ensure long-term success.' },
];

export const portfolioData = [
  {
    title: 'Aura Aesthetics Clinic',
    category: 'Beauty & Wellness',
    image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    tags: ['Web Design', 'AI Booking', 'SEO']
  },
  {
    title: 'Lumina Legal Partners',
    category: 'Professional Services',
    image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    tags: ['Web Design', 'AI Lead Gen']
  },
  {
    title: 'Vertex Real Estate',
    category: 'Property',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    tags: ['Web Design', 'WhatsApp Bot']
  },
  {
    title: 'Prime Fitness Studio',
    category: 'Health & Fitness',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    tags: ['Web Design', 'Automated Emails']
  }
];

export const testimonialsData = [
  {
    name: 'Sarah Jenkins',
    profession: 'Owner',
    business: 'Glow Medical Spa',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80',
    review: "The level of professionalism is unmatched. They didn't just build a beautiful website; they integrated an AI booking system that has reduced our front-desk workload by 40%. A true premium agency."
  },
  {
    name: 'David Chen',
    profession: 'Managing Partner',
    business: 'Chen & Associates Law',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80',
    review: "We needed a digital presence that conveyed trust and authority. The team delivered a flawless, fast-loading site. Their ongoing maintenance gives us complete peace of mind to focus on our clients."
  },
  {
    name: 'Elena Rodriguez',
    profession: 'Founder',
    business: 'Haven Interior Design',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80',
    review: "Stunning design work. They captured our aesthetic perfectly and integrated a smart AI lead qualification tool that ensures we only spend time on serious inquiries. Worth every penny."
  }
];

export const faqsData = [
  {
    question: "Do you build custom websites or use templates?",
    answer: "We build custom, handcrafted websites tailored specifically to your brand's unique identity and business goals. We do not rely on generic templates, ensuring your digital presence stands out from competitors."
  },
  {
    question: "What exactly does AI Tool Integration mean for my business?",
    answer: "AI Integration means we add smart automation to your site—like AI chatbots that answer customer queries 24/7, smart booking systems, and automated follow-ups. This saves you time, reduces manual work, and captures leads even when you're sleeping."
  },
  {
    question: "Why do I need an ongoing maintenance plan?",
    answer: "A website is a living digital asset. Our maintenance plans ensure your site remains secure against threats, loads lightning-fast, stays optimized for search engines, and receives regular software updates, preventing costly downtime."
  },
  {
    question: "How long does it take to design and launch a website?",
    answer: "A typical premium website takes 3 to 6 weeks from our initial consultation to final launch. This ensures adequate time for strategic planning, custom design, rigorous testing, and AI integration."
  },
  {
    question: "Will my website work well on mobile phones?",
    answer: "Absolutely. We adopt a strict mobile-first approach. Over 60% of web traffic comes from mobile devices, so we ensure your site looks flawless and functions perfectly on all screen sizes."
  }
];
