import { ThemeProvider } from './components/ThemeProvider';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Industries } from './components/Industries';
import { AIServices } from './components/AIServices';
import { Maintenance } from './components/Maintenance';
import { Portfolio } from './components/Portfolio';
import { Process } from './components/Process';
import { Testimonials } from './components/Testimonials';
import { FAQ } from './components/FAQ';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';

export default function App() {
  return (
    <ThemeProvider defaultTheme="light">
      <div className="min-h-screen font-sans selection:bg-brand-500/30">
        <Navbar />
        <main>
          <Hero />
          <Features />
          <Industries />
          <AIServices />
          <Maintenance />
          <Portfolio />
          <Process />
          <Testimonials />
          <FAQ />
          <Contact />
        </main>
        <Footer />
        <FloatingActions />
      </div>
    </ThemeProvider>
  );
}
